/*

Credentials file

*/

#pragma once

// Only one of these settings must be defined at the same time
#define USE_ABP
//#define USE_OTAA // OTAA not working ATM

#ifdef USE_ABP

    // LoRaWAN NwkSKey, network session key (LSB)
    static const u1_t PROGMEM NWKSKEY[16] = { 0xCE, 0xE8, 0xCA, 0x9D, 0xC9, 0xDD, 0x4B, 0xD7, 0x81, 0x24, 0x6A, 0x74, 0x7F, 0x60, 0xEF, 0x44 };

    // LoRaWAN AppSKey, application session key (LSB)
    static const u1_t PROGMEM APPSKEY[16] = { 0xE1, 0xD6, 0x3E, 0x4A, 0x82, 0x67, 0x9A, 0x8B, 0x66, 0x38, 0xF9, 0xDB, 0xC6, 0xBA, 0x93, 0x4D };

    // LoRaWAN end-device address (DevAddr)
    // This has to be unique for every node
    static const u4_t DEVADDR             = 0x260B2A3C;

#endif

#ifdef USE_OTAA

    // This EUI must be in little-endian format, so least-significant-byte
    // first (LSB). When copying an EUI from ttnctl output, this means to reverse
    // the bytes. For TTN issued EUIs the last bytes should be 0xD5, 0xB3,
    // 0x70.
    static const u1_t PROGMEM APPEUI[8]  = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

    // This should also be in little endian format (LSB), see above.
    static const u1_t PROGMEM DEVEUI[8]  = { 0x00, 0x05, 0xF4, 0xBE, 0xE1, 0x36, 0x06, 0x22 };

    // This key should be in big endian format (or, since it is not really a
    // number but a block of memory, endianness does not really apply). In
    // practice, a key taken from ttnctl can be copied as-is.
    // The key shown here is the semtech default key.
    static const u1_t PROGMEM APPKEY[16] = { 0x63, 0xDE, 0xA1, 0xD7, 0x18, 0x81, 0x6A, 0x99, 0x48, 0x6D, 0x14, 0x95, 0x3F, 0x47, 0x94, 0xD2 };

#endif
